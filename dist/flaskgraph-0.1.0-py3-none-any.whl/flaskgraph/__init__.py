from .graph import ChartJS
graph = ChartJS()
